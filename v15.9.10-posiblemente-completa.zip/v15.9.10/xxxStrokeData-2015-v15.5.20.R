require(pracma)

TOP.DIR <- file.path("", "research")
ARI.DIR <- file.path(TOP.DIR, "ARI-R")
DATA.DIR <- file.path(TOP.DIR, "Data")

# [side effect: atARI, carSignal, Metric-utils, Rounding-utils]
MFARI.SCRIPT.BASENAME <- paste("mfARIdev2", sep = "-")
MFARI.SCRIPT.BASENAME <- paste(MFARI.SCRIPT.BASENAME, "R", sep = ".")
MFARI.SCRIPT.NAME <- file.path(ARI.DIR, MFARI.SCRIPT.BASENAME)
source(MFARI.SCRIPT.NAME)


get.normalised.ari.templates <- function(
      normalised.ABP,
      sample.release,
      params
      )
{
  
  at.params <-get.AT.decimal.templates.parameters(
    rounding.digits = params[["at.param.rounding.digits"]]
  )
  r <- 1:nrow(at.params)
  
  .tmp.fun <- function(i) get.theoretical.CBFV.response(
    T = at.params[i, 1],
    D = at.params[i, 2],
    K = at.params[i, 3],
    time.instants = params[["time.instants"]],
    ABP.normalised = normalised.ABP,
    sampling.time = params[["sampling.time"]],
    stabilisation.time = params[["stabilisation.time"]]
  )
  templates <- lapply(r, .tmp.fun)
  
  .tmp.fun <- function(t) normalise.CBFV.signal(
    time.instants = params[["time.instants"]],
    CBFV.signal = t[["CBFV.theoretical.response"]],
    sample.release = sample.release,
    sampling.time = params[["sampling.time"]],
    baseline.initial.time = params[["baseline.initial.time"]],
    baseline.final.time = params[["baseline.final.time"]],
    min.CBFV.max.delta.time = params[["min.CBFV.max.delta.time"]],
    CBFV.rounding.digits = params[["CBFV.rounding.digits"]],
    time.tol = params[["time.tol"]]
  )
  normalised.templates <- lapply(templates, .tmp.fun)
  
  .tmp.fun <- function(t) t[["normalised.CBFV.signal"]]
  normalised.templates <- lapply(normalised.templates, .tmp.fun)
  
  names(normalised.templates) <- sprintf("%.1f", at.params[[4]])
  
  normalised.templates
}


process.manoeuvre.side <- function(ABP.signal, CBFV.signal, sample.release,
                                   normalised.ari.templates, params)
{  
  mfari <- get.mfARI.parameters(
    time.instants = params[["time.instants"]],
    ABP.signal = ABP.signal,
    CBFV.signal = CBFV.signal,
    sampling.time = params[["sampling.time"]],
    time.release = params[["time.release"]],
    baseline.initial.time = params[["baseline.initial.time"]],
    baseline.final.time = params[["baseline.final.time"]],
    min.ABP.max.delta.time = params[["min.ABP.max.delta.time"]],
    transient.ABP.duration = params[["transient.ABP.duration"]],
    min.CBFV.max.delta.time = params[["min.CBFV.max.delta.time"]], 
    min.transient.CBFV.duration = params[["min.transient.CBFV.duration"]],
    max.transient.CBFV.duration = params[["max.transient.CBFV.duration"]],
    steady.CBFV.duration = params[["steady.CBFV.duration"]],
    min.Ks = params[["min.Ks"]],
    max.Ks = params[["max.Ks"]],
    min.ABP.angle = params[["min.ABP.angle"]],
    max.ABP.angle = params[["max.ABP.angle"]],
    min.CBFV.angle = params[["min.CBFV.angle"]],
    max.CBFV.angle = params[["max.CBFV.angle"]],
    min.Phi = params[["min.Phi"]],
    max.Phi = params[["max.Phi"]],
    keep.details = FALSE,
    time.tol = params[["time.tol"]]
  )
  Ks <- mfari[["Ks"]]
  Delta.tau <- mfari[["Delta.tau"]]
  Phi <- mfari[["Phi"]]
  mfARI <- get.mfARI(Ks, Delta.tau, Phi)
  
  atari <- get.best.templates(
    time.instants = params[["time.instants"]],
    signal = mfari[["normalised.CBFV.signal"]],
    templates = normalised.ari.templates,
    referential.time.instant = params[["referential.time.instant"]],
    delta.time.before.ref = params[["delta.time.before.ref"]],
    delta.time.after.ref = params[["delta.time.after.ref"]],
    comparison.function = params[["comparison.function"]],
    keep.details = FALSE
  )
  best.i <- atari[["best.template.index"]]
  dARI.MSE <- atari[["best.fit.value"]]
  dARI <- as.numeric(names(normalised.ari.templates)[best.i])
  
  d <- data.frame(Ks, Delta.tau, Phi, mfARI, dARI.MSE, dARI)
  d <- mapply(round, d, c(params[["Ks.rounding.digits"]],
                          params[["Delta.tau.rounding.digits"]],
                          params[["Phi.rounding.digits"]],
                          params[["index.rounding.digits"]],
                          params[["MSE.rounding.digits"]],
                          params[["index.rounding.digits"]]),
              SIMPLIFY = FALSE,
              USE.NAMES = TRUE
             )
  
  data.frame(d)
}


process.manoeuvre.file <- function(src.data.dir, mvre.data, params)
{
  cat("Processing ", mvre.data[["Manoeuvre"]], "\n")
  
  m <- regexec("([A-Z]+)(\\d+)", mvre.data[["Manoeuvre"]])
  m <- regmatches(mvre.data[["Manoeuvre"]], m)
  m <- m[[1]]
  if(length(m) < 3)
    stop("subject name and manoeuvre number could not be extracted")
  Subject <- m[2]
  Manoeuvre <- m[3]
  
  src.basename <- paste(mvre.data[["Manoeuvre"]], "PAR", sep = ".")
  src.name <- file.path(src.data.dir, src.basename)
  if(!file.exists(src.name))
    stop("source data file could not be found: ", src.name)
  
  mvre.signals <- read.csv(file = src.name, header = FALSE, sep = "")
  if(nrow(mvre.signals) != mvre.data[["Length"]])
    stop("unexpected length for the signals")
  
  nsamples.until.release <- round(params[["time.until.release"]] /
                                  params[["sampling.time"]])
  nsamples.after.release <- round(params[["time.after.release"]] /
                                  params[["sampling.time"]])
  initial.sample <- mvre.data[["Release"]] - nsamples.until.release
  if(initial.sample < 1)
    stop("signal is too short for specified time until release")
  final.sample <- mvre.data[["Release"]] + nsamples.after.release
  if(final.sample > mvre.data[["Length"]])
    stop("signal is too short for specified time after release")
  
  samples <- initial.sample:final.sample
  if(length(samples) != length(params[["time.instants"]]))
    stop("extracted signal does not much number of time instants")
  
  ABP.signal <- mvre.signals[[3]][samples]
  left.CBFV.signal <- mvre.signals[[2]][samples]
  right.CBFV.signal <- mvre.signals[[4]][samples]
  
  sample.release <- which(are.tolerably.equal(params[["time.instants"]],
                                              params[["time.release"]],
                                              params[["time.tol"]]))
  if(length(sample.release) != 1)
    stop("could not determined a unique sample for time of release: ",
         sample.release)
  
  ABP.normalisation <- normalise.ABP.signal(
    time.instants = params[["time.instants"]],
    ABP.signal = ABP.signal,
    sample.release = sample.release,
    sampling.time = params[["sampling.time"]],
    baseline.initial.time = params[["baseline.initial.time"]],
    baseline.final.time = params[["baseline.final.time"]],
    min.ABP.max.delta.time = params[["min.ABP.max.delta.time"]],
    ABP.rounding.digits = params[["ABP.rounding.digits"]],
    time.tol = params[["time.tol"]]
  )
  if(is.null(ABP.normalisation[["normalised.ABP.signal"]]))
  {
    cat("  ", "Omitting... ABP signal could not be normalised", "\n")
    return(NULL)
  }
  
  normalised.ari.templates <- get.normalised.ari.templates(
    normalised.ABP = ABP.normalisation[["normalised.ABP.signal"]],
    sample.release = sample.release,
    params = params
  )
  
  # Left hemisphere
  left.results <- NULL
  if(mvre.data[["LeftOK"]])
  {
    left.results <- data.frame(Subject, Manoeuvre, Side = "Left")
    left.result <- process.manoeuvre.side(
      ABP.signal = ABP.signal,
      CBFV.signal = left.CBFV.signal,
      sample.release = sample.release,
      normalised.ari.templates = normalised.ari.templates,
      params = params
    )
    left.results <- cbind(left.results, left.result)
    
  } # End if left CBFV is ok
  
  # Right hemisphere
  right.results <- NULL
  if(mvre.data[["RightOK"]])
  {
    right.results <- data.frame(Subject, Manoeuvre, Side = "Right")
    right.result <- process.manoeuvre.side(
      ABP.signal = ABP.signal,
      CBFV.signal = right.CBFV.signal,
      sample.release = sample.release,
      normalised.ari.templates = normalised.ari.templates,
      params = params
    )
    right.results <- cbind(right.results, right.result)
    
  } # End if right CBFV is ok
  
  rbind(left.results, right.results)
}


read.manoeuvres <- function(manoeuvres.csv.name)
{
  manoeuvres.data <- read.csv(file = manoeuvres.csv.name,
                              comment.char = "#")
  manoeuvres.data[[1]] <- as.character(manoeuvres.data[[1]])
  manoeuvres.data[[2]] <- as.integer(manoeuvres.data[[2]])
  manoeuvres.data[[3]] <- as.integer(manoeuvres.data[[3]])
  manoeuvres.data[[4]] <- as.logical(manoeuvres.data[[4]])
  manoeuvres.data[[5]] <- as.logical(manoeuvres.data[[5]])
  
  manoeuvres.data
}

process.manoeuvre.files <- function(
      src.data.dir,
      manoeuvres.csv.name,
      params
      )
{
  manoeuvres.data <-
    read.manoeuvres(manoeuvres.csv.name = manoeuvres.csv.name)
  
  results <- NULL
  for(i in 1:nrow(manoeuvres.data))
  {
    manoeuvre.data <- as.list(manoeuvres.data[i, ])
    manoeuvre.results <- process.manoeuvre.file(
      src.data.dir = src.data.dir,
      mvre.data = manoeuvre.data,
      params = params
    )
    
    results <- rbind(results, manoeuvre.results)
  }
  
  results
}


get.manoeuvres.indices <- function(
      src.data.dir,
      manoeuvres.csv.name,
      tgt.data.dir,
      tgt.csv.suffix,
      params
      )
{
  tgt.csv.name <- paste("Manoeuvre", "results", tgt.csv.suffix, sep = "-")
  tgt.csv.name <- paste(tgt.csv.name, "csv", sep = ".")
  tgt.csv.name <- file.path(tgt.data.dir, tgt.csv.name)
  tgt.csv.exists <- file.exists(tgt.csv.name)
  
  if(all(tgt.csv.exists, params[["read.only.if.data.exists"]]))
    return(read.csv(tgt.csv.name))
  
  results <- process.manoeuvre.files(
    src.data.dir = src.data.dir,
    manoeuvres.csv.name = manoeuvres.csv.name,
    params = params
  )
  
  # Results by manoeuvre
  
  if(any(!tgt.csv.exists, params[["overwrite.tgt.csv.file"]]))
  {
    dir.create(tgt.data.dir, showWarnings = FALSE, recursive = TRUE)
    write.csv(results, file = tgt.csv.name, row.names = FALSE)
  }
  
  tgt.csv.name <- paste("Resultados", "por", "maniobra", tgt.csv.suffix, sep = "-")
  tgt.csv.name <- paste(tgt.csv.name, "csv", sep = ".")
  tgt.csv.name <- file.path(tgt.data.dir, tgt.csv.name)
  
  if(any(!file.exists(tgt.csv.name), params[["overwrite.tgt.csv.file"]]))
  {
    dir.create(tgt.data.dir, showWarnings = FALSE, recursive = TRUE)
    write.csv2(results, file = tgt.csv.name, row.names = FALSE)
  }
  
  # Decimal ARI summary table
  
  table.ari <- results[, c("Subject", "Manoeuvre", "Side", "dARI")]
  table.ari <- reshape(
    data = table.ari,
    idvar = c("Subject", "Side"),
    timevar = "Manoeuvre",
    direction = "wide"
  )
  ncols <- ncol(table.ari)
  means <- apply(table.ari[, 3:ncols], 1, mean, na.rm = TRUE)
  sds <- apply(table.ari[, 3:ncols], 1, sd, na.rm = TRUE)
  table.ari[["Mean"]] <- round(means, params[["index.rounding.digits"]])
  table.ari[["SD"]] <- round(sds, params[["index.rounding.digits"]] + 1)
  
  tgt.csv.name <- paste("dARI", "table", tgt.csv.suffix, sep = "-")
  tgt.csv.name <- paste(tgt.csv.name, "csv", sep = ".")
  tgt.csv.name <- file.path(tgt.data.dir, tgt.csv.name)
  tgt.csv.exists <- file.exists(tgt.csv.name)
  
  if(any(!tgt.csv.exists, params[["overwrite.tgt.csv.file"]]))
  {
    dir.create(tgt.data.dir, showWarnings = FALSE, recursive = TRUE)
    write.csv(table.ari, file = tgt.csv.name, row.names = FALSE)
  }
  
  tgt.csv.name <- paste("Tabla", "ARI", "decimal", tgt.csv.suffix, sep = "-")
  tgt.csv.name <- paste(tgt.csv.name, "csv", sep = ".")
  tgt.csv.name <- file.path(tgt.data.dir, tgt.csv.name)
  
  if(any(!file.exists(tgt.csv.name), params[["overwrite.tgt.csv.file"]]))
  {
    dir.create(tgt.data.dir, showWarnings = FALSE, recursive = TRUE)
    write.csv2(table.ari, file = tgt.csv.name, row.names = FALSE)
  }
    
  # mfARI summary table
  
  table.mfari <- results[, c("Subject", "Manoeuvre", "Side", "mfARI")]
  table.mfari <- reshape(
    data = table.mfari,
    idvar = c("Subject", "Side"),
    timevar = "Manoeuvre",
    direction = "wide"
  )
  ncols <- ncol(table.mfari)
  means <- apply(table.mfari[, 3:ncols], 1, mean, na.rm = TRUE)
  sds <- apply(table.mfari[, 3:ncols], 1, sd, na.rm = TRUE)
  table.mfari[["Mean"]] <- round(means, params[["index.rounding.digits"]])
  table.mfari[["SD"]] <- round(sds, params[["index.rounding.digits"]] + 1)
  
  tgt.csv.name <- paste("mfARI", "table", tgt.csv.suffix, sep = "-")
  tgt.csv.name <- paste(tgt.csv.name, "csv", sep = ".")
  tgt.csv.name <- file.path(tgt.data.dir, tgt.csv.name)
  tgt.csv.exists <- file.exists(tgt.csv.name)
  
  if(any(!tgt.csv.exists, params[["overwrite.tgt.csv.file"]]))
  {
    dir.create(tgt.data.dir, showWarnings = FALSE, recursive = TRUE)
    write.csv(table.mfari, file = tgt.csv.name, row.names = FALSE)
  }
  
  tgt.csv.name <- paste("Tabla", "mfARI", tgt.csv.suffix, sep = "-")
  tgt.csv.name <- paste(tgt.csv.name, "csv", sep = ".")
  tgt.csv.name <- file.path(tgt.data.dir, tgt.csv.name)
  
  if(any(!file.exists(tgt.csv.name), params[["overwrite.tgt.csv.file"]]))
  {
    dir.create(tgt.data.dir, showWarnings = FALSE, recursive = TRUE)
    write.csv2(table.mfari, file = tgt.csv.name, row.names = FALSE)
  }
  
  # Returns results by manoeuvre
  results
}


run <- function(group = c("Controls", "Patients"))
{
  group <- match.arg(group)
  this.version <- "v15.5.20"

  params <- list()
  params[["sampling.time"]] <- 0.2
  params[["time.until.release"]] <- 10
  params[["time.after.release"]] <- 20
  params[["time.release"]] <- 0
  t <- seq(
    -params[["time.until.release"]],
    params[["time.after.release"]],
    by = params[["sampling.time"]]
  )
  params[["time.instants"]] <- round(t + params[["time.release"]], 1)
  params[["baseline.initial.time"]] <- -5
  params[["baseline.final.time"]] <- params[["time.release"]]
  params[["min.ABP.max.delta.time"]] <- round(5 * 0.8, 1)
  params[["min.CBFV.max.delta.time"]] <- round(8 * 0.8, 1)
  params[["transient.ABP.duration"]] <- 6
  params[["min.transient.CBFV.duration"]] <- 1.5
  params[["max.transient.CBFV.duration"]] <- 10
  params[["steady.CBFV.duration"]] <- 6
  params[["min.Ks"]] <- 0.0
  params[["max.Ks"]] <- 1.022095
  params[["min.ABP.angle"]] <-  0.0
  params[["max.ABP.angle"]] <- 90.0
  params[["min.CBFV.angle"]] <-  0.0
  params[["max.CBFV.angle"]] <- 90.0
  params[["min.Phi"]] <- 0.0
  params[["max.Phi"]] <- 35.238932
  params[["referential.time.instant"]] <- params[["time.release"]]
  params[["delta.time.before.ref"]] <- 0
  params[["delta.time.after.ref"]] <- round(20 * 0.8, 1)
  params[["comparison.function"]] <- get.MSE
  params[["stabilisation.time"]] <- 30
  params[["at.param.rounding.digits"]] <- 6
  params[["time.tol"]] <- params[["sampling.time"]] / 100
  params[["ABP.rounding.digits"]] <- 2
  params[["CBFV.rounding.digits"]] <- 2
  params[["Ks.rounding.digits"]] <- 4
  params[["Delta.tau.rounding.digits"]] <- 1
  params[["Phi.rounding.digits"]] <- 2
  params[["index.rounding.digits"]] <- 1
  params[["MSE.rounding.digits"]] <- 4
  params[["read.only.if.data.exists"]] <- TRUE
  params[["overwrite.tgt.csv.file"]] <- FALSE
  
  baseline.duration.str <- sprintf(
    "signals_base_len=%.1fs",
    params[["baseline.final.time"]] - params[["baseline.initial.time"]]
  )
  min.ABP.max.delta.time.str <-
    sprintf("min_ABP_win_len=%.1fs", params[["min.ABP.max.delta.time"]])
  
  min.CBFV.max.delta.time.str <-
    sprintf("min_CBFV_win_len=%.1fs", params[["min.CBFV.max.delta.time"]])
  
  src.data.dir <- file.path(DATA.DIR, "Stroke-Leicester")
  test.data.dir  <- file.path(ARI.DIR, "StrokeData-2015")
  tgt.data.dir <- file.path(test.data.dir, "Indices", this.version, group)
  
  tgt.csv.suffix <- paste(
    group,
    baseline.duration.str,
    min.ABP.max.delta.time.str,
    min.CBFV.max.delta.time.str,
    sep = "-"
  )
  
  manoeuvres.csv.basename <- paste(group, "manoeuvres", "1", sep = "-")
  manoeuvres.csv.name <- paste(manoeuvres.csv.basename, "csv", sep = ".")
  manoeuvres.csv.name <- file.path(test.data.dir, manoeuvres.csv.name)
  if(!file.exists(manoeuvres.csv.name))
    stop("CSV file with subjects' information could not be found: ",
         manoeuvres.csv.name)
  
  results <- get.manoeuvres.indices(
    src.data.dir = src.data.dir,
    manoeuvres.csv.name = manoeuvres.csv.name,
    tgt.data.dir = tgt.data.dir,
    tgt.csv.suffix = tgt.csv.suffix,
    params = params
  )
  
  results
}
